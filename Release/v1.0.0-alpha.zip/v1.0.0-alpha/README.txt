1) Download ffmpeg.exe , ffprobe.exe (64bit or 32bit) from:
https://ffmpeg.zeranoe.com/builds/

2) Extract from the zip the files ffmpeg.exe , ffprobe.exe into Easy265File\ffmpeg\bin

